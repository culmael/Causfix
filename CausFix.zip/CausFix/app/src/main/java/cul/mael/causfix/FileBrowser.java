package cul.mael.causfix;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.res.*;
import android.database.*;
import android.graphics.drawable.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.util.*;
import android.view.*;
import android.view.ContextMenu.*;
import android.widget.*;
import java.io.*;
import java.lang.ref.*;
import java.lang.reflect.*;
import java.net.*;
import java.text.*;
import java.util.*;
import cul.mael.causfix.*;



public class FileBrowser extends ListActivity
{

    private final static String empty = "";
    private final static String TAG = "FileBrowser";
    private Stack<Integer> pos = new Stack<Integer>();
    private List<File> xFileList;
    private FileListAdapter mAdapter;
    private static File mCurrentDir, mCurrentF;
    private int position;
    String ipath;
   
private Comparator<File> sortByType = new Comparator<File>()
{
        public int compare(File file1,File file2)
		{
            boolean a = file1.isDirectory();
            boolean b = file2.isDirectory();
            if (a && !b)
				{
                return -1;
            }
			else if (!a && b)
			{
                return 1;
            }else if (a && b)
			{
                return file1.getName().toLowerCase().compareTo(file2.getName().toLowerCase());
            }else{
                return file1.getName().compareTo(file2.getName());
            }
        }
    };
  
@Override
public void onCreate(Bundle savedInstanceState)
{
super.onCreate(savedInstanceState);
ipath = "/sdcard";
if (mCurrentDir == null)
{
mCurrentDir = new File(ipath);
}
mAdapter = new FileListAdapter(getApplication());
mAdapter.registerDataSetObserver(new DataSetObserver()
{
@Override
public void onInvalidated()
{
updateAndFilterFileList(empty);
}});
registerForContextMenu(getListView());
updateAndFilterFileList(empty);
setListAdapter(mAdapter);
setSelection(position);
}

private void updateAndFilterFileList(final String query)
{
        File[] files = mCurrentDir.listFiles();
        if (files != null)
			{
            setTitle(mCurrentDir.getPath());
            List<File> work = new Vector<File>(files.length);
            for (File file : files)
			{
                if (query == null || query.equals(empty))
					{
                    work.add(file);
                }
				else if (file.getName().toLowerCase().contains(query.toLowerCase()))
					{
                    work.add(file);
                }
            }
            Collections.sort(work,sortByType);
            xFileList = work;
            File parent = mCurrentDir.getParentFile();
            if (parent != null)
				{
                xFileList.add(0, new File(mCurrentDir.getParent())
				{
                    @Override
                    public boolean isDirectory()
					{
                        return true;
                    }

                @Override
                    public String getName()
					{
                        return "..";
                    }
                });
            }
        }
    }


private void openFile(final File file)
{
try
{
Intent intent = new Intent(FileBrowser.this, MainActivity.class);
//intent.putExtra(FileBrowser.FILE_PATH_EXTRA, file.getAbsolutePath());
MainActivity mac = MainActivity.getInstance();
MainActivity.spath = file.getAbsolutePath();
//mac.exec();
intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
startActivity(intent);
}
catch(Exception e)
{
toast("Error bro");
}}
		
@Override
public void onConfigurationChanged(Configuration conf)
{
super.onConfigurationChanged(conf);
}

private boolean isTargetFile(String file)
{
final String ext = ".caustic";
String name = file.toLowerCase(Locale.ENGLISH);
        if (name.endsWith(ext))
		return true;
        else
        return false;
}

/*@Override
public boolean onCreateOptionsMenu(Menu menu)
{
super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.meu, menu);
		return true;
}*/

/*@Override
public boolean onOptionsItemSelected(MenuItem item)
	{
		if (item.getItemId() == R.id.chg)
		{
			if (ipath.equals("/sdcard"))
            {
			 ipath = "/storage";
             } else {
			 ipath = "/sdcard";
             }
		toast("Change");
		}
		return true;
	}*/

@Override
public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)
{
super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Options");
        File file = null;
        AdapterView.AdapterContextMenuInfo info;
        try
		{
            info = (AdapterView.AdapterContextMenuInfo) menuInfo;
            file = (File) getListView().getItemAtPosition(info.position);
            if (!file.isDirectory())
                menu.add(Menu.NONE, R.string.view, Menu.NONE, R.string.view);
        }
		catch (ClassCastException e)
		{
            Log.e(TAG,"Bad menuInfo" + e);
        }
        if (file.getName().equals(".."))
			return;
        menu.add(Menu.NONE, R.string.info, Menu.NONE, R.string.info);
}

@Override
public boolean onContextItemSelected(MenuItem item)
{
AdapterView.AdapterContextMenuInfo info;
        try
		{
            info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        }
		catch (ClassCastException e)
		{
            Log.e(TAG,"Bad menuInfo" + e);
            return false;
        }
        mCurrentF = (File) getListView().getItemAtPosition(info.position);
        position = info.position;

        switch(item.getItemId())
		{
            case R.string.view:
                viewCurrent();
                return true;
            case R.string.info:
                showInfo(mCurrentF);
                return true;
        }
        return false;
}

public void showInfo(File file)
{
	SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
	Date date = new Date(file.lastModified());
    Long lo = Runtime.getRuntime().maxMemory();
    Long lo2 = getFreeSpace();
    String mh = mAdapter.convertBytesLength(lo);
    String mh2 = mAdapter.convertBytesLength(lo2);
		String s ="Maxheap: " + mh;
		s += "\nFree space memory: " + mh2;
		s += "\nAbsolute file: " + file.getAbsoluteFile();
		s += "\n Absolute path: " + file.getAbsolutePath();
		s += "\nName: " + file.getName();
		s += "\n Free space: " + getFileSize(file.getFreeSpace());
		
		s += "\nPath: " + file.getPath();
		s += "\n Total space: " + getFileSize(file.getTotalSpace());
		
		s += "\nCan execute ? " + file.canExecute();
		s += "\n Can read ? " + file.canRead();
		s += "\nCan write ? " + file.canWrite();
		s += "\n Usable space: " +  mAdapter.convertBytesLength(file.getUsableSpace());
		s += "\nLast modified: " + format.format(date);
		if (file.isDirectory() == true)
			s += "\n " + "Is a dir";
		else
			s += "\n " + "Is a file";
		s += "\n Is hidden ? " + file.isHidden();
		s += "\nIs absolute ? " + file.isAbsolute();
		s += "\n Lenght: " + getFileSize(file.length());
		s += "\nTo String: " + file.toString();
		s += "\n URI " + file.toURI();
		s += "\nList: " + file.list();
        s += "\nCache dir: " + getRecordedFilename(this);
		AlertDialog.Builder alert = new AlertDialog.Builder(this);
		alert.setTitle("Show info");
		alert.setMessage(s);
		alert.setNeutralButton(R.string.ok, null);
        alert.show();
}

    public String getRecordedFilename(Context var0) {
        return (new File(var0.getCacheDir(), "input.wav")).toString();
    }
        
public long getFreeSpace()
{
      StatFs var1 = new StatFs(Environment.getRootDirectory().getAbsolutePath());
      return (long)(var1.getAvailableBlocks() * var1.getBlockSize());
   }

public String getFileSize(long size)
{
		long l = 1048576;
		long l2 = 1024;
		NumberFormat fmt = new DecimalFormat("#.##");
		String sizeString = "";
		if (size < l2) {
			sizeString = new StringBuilder(String.valueOf(size)).append(" Bytes").toString();
		}
		if (size >= l2) {
			if (size < l) {
				sizeString = new StringBuilder(String.valueOf(fmt.format((((double) (size)) / 1024.0d)))).append(" KB").toString();
			}
		}
		if (size >= l) {
			return new StringBuilder(String.valueOf(fmt.format((((double) (size)) / 1048576.0d)))).append(" MB").toString();
		} else {
			return sizeString;
		}
	}

@Override
public boolean onKeyDown(int keyCode, KeyEvent event)
{
if (keyCode == KeyEvent.KEYCODE_BACK)
{
if (xFileList != null && xFileList.size() > 0)
{
File first = xFileList.get(0);
if (first.getName().equals("..") && first.getParentFile() != null)
{
mCurrentDir = first;
mAdapter.notifyDataSetInvalidated();
if (!pos.empty())
 setSelection(pos.pop());
return true;
}}
if (mCurrentDir != null && mCurrentDir.getParentFile() != null)
{
mCurrentDir = mCurrentDir.getParentFile();
mAdapter.notifyDataSetInvalidated();
if (!pos.empty())
 setSelection(pos.pop());
return true;
}
if (mCurrentDir != null && mCurrentDir.getParent() == null)
{
toast("Cancel");
finish();
}}
return super.onKeyDown(keyCode, event);
}
    
@Override
protected void onSaveInstanceState(Bundle outState)
{
super.onSaveInstanceState(outState);
outState.putString("dir_path", mCurrentDir.getAbsolutePath());
}

@Override
protected void onRestoreInstanceState(Bundle savedInstanceState)
{
super.onRestoreInstanceState(savedInstanceState);
String dir = savedInstanceState.getString("dir_path");
mCurrentDir = new File(dir);
mAdapter.notifyDataSetInvalidated();
}

@Override
protected void onResume()
{
super.onResume();
mAdapter.notifyDataSetChanged();
}

@Override
public boolean onPrepareOptionsMenu(Menu menu)
{
super.onPrepareOptionsMenu(menu);
return true;
}

@Override
public void onDestroy()
{
super.onDestroy();
mCurrentF = null;
mCurrentDir = null;
pos = null;
System.gc();
}

private void viewCurrent()
{
Intent intent = new Intent(Intent.ACTION_VIEW);
Uri uri = Uri.fromFile(mCurrentF);
String mime = URLConnection.guessContentTypeFromName(uri.toString());

if (mime != null)
{
if ("text/txt".equals(mime) || "text/xml".equals(mime))
{
intent.setDataAndType(uri, "text/plain");
}else{
intent.setDataAndType(uri, mime);
}
}else{
intent.setDataAndType(uri, "*/*");
}
try
{
startActivity(intent);
}
catch (Exception e)
{
showMessage(FileBrowser.this,"Intent Exception",e.getMessage());
toast("" + e);
}}

private void toast(String message)
{
Toast.makeText(FileBrowser.this, message, Toast.LENGTH_LONG).show();
}

@Override
protected void onListItemClick(ListView list, View view, int position, long id)
{
final File file = (File) list.getItemAtPosition(position);
this.position = position;
mCurrentF = file;
if (file.isDirectory())
{
mCurrentDir = file;
pos.push(list.getFirstVisiblePosition());
mAdapter.notifyDataSetInvalidated();
return;
}
else if (isTargetFile(file.getName()))
{
openFile(file);
}}

@Override
protected Dialog onCreateDialog(int id)
		{
            ProgressDialog dialog = new ProgressDialog(this);
            dialog.setMessage("Wait...Please!");
            dialog.setIndeterminate(true);
            dialog.setCancelable(false);
            return dialog;
        }

public static void showMessage(Context context,String title,String message)
	{
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setNeutralButton(R.string.ok, null);
        builder.show();
    }


private class FileListAdapter extends BaseAdapter
	{
	
        protected final Context mContext;
        protected final LayoutInflater mInflater;
        private SimpleDateFormat format = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
           
        public FileListAdapter(Context context)
		{
            mContext = context;
            mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        public int getCount()
		{
            return getFileList().size();
        }

        public Object getItem(int position)
		{
            return getFileList().get(position);
        }

        public long getItemId(int position)
		{
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent)
		{
            final File file = getFileList().get(position);
            String name = file.getName().toLowerCase();

            RelativeLayout container;
            if (convertView == null)
				{
                container = (RelativeLayout) mInflater.inflate(R.layout.list_item_details, null);
            } else {
                container = (RelativeLayout) convertView;
            }

            final ImageView icon = (ImageView) container.findViewById(R.id.icon);
            if (file.isDirectory())
				{
                icon.setImageResource(R.drawable.folder);
            }
			else if (isTargetFile(name))
			{
                icon.setImageResource(R.drawable.image);
            }else{
                icon.setImageResource(R.drawable.file);
            }
           
            Typeface tf = Typeface.createFromAsset(getApplicationContext().getAssets(), "fonts/SourceCodePro-Black.ttf");
            
            TextView text = (TextView) container.findViewById(R.id.text);
            TextView time = (TextView) container.findViewById(R.id.times);
            TextView size = (TextView) container.findViewById(R.id.size);
            text.setTypeface(tf);
            text.setText(file.getName());

            Date date = new Date(file.lastModified());
            time.setText(format.format(date));
            if (file.isDirectory())
				{
                size.setText("");
            }else{
                size.setText(convertBytesLength(file.length()));
            }
            return container;
        }

        private String convertBytesLength(long len)
		{
            if (len < 1024)
				{
                return len + "B";
            }
            if (len < 1024 * 1024)
				{
                return String.format("%.2f%s",(len / 1024.0),"K");
            }
            if (len < 1024 * 1024 * 1024)
                return String.format("%.2f%s",(len / (1024 * 1024.0)),"M");
            return String.format("%.2f%s",(len / (1024 * 1024 * 1024.0)),"G");
        }

        protected List<File> getFileList()
		{
            return xFileList;
        }
    }
}
