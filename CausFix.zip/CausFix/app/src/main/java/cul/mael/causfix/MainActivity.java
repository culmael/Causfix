package cul.mael.causfix;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.*;
import android.text.method.*;
import android.text.util.*;
import android.util.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;

public class MainActivity extends Activity implements View.OnClickListener
 {
 
	public static String spath = "";
	MyTextView tvf, tvs, tve, tvr;
	Button btn, btn2, btn3;
	EditText et;
    private static MainActivity instance;
    public RandomAccessFile raf;
    ProgressBar pb;
    ScrollView sv;
    private static final int SHOWPROGRESS = 1; 
    private static final int DISMISSPROGRESS = 2; 
    private Handler mHandler = new Handler()
    {
        @Override
            public void handleMessage(Message msg)
            {
                switch(msg.what)
                {
                    case SHOWPROGRESS:
                        MainActivity.this.pb.setVisibility(View.VISIBLE);
                        break;
                    case DISMISSPROGRESS:
                        MainActivity.this.pb.setVisibility(View.GONE);
                        MainActivity.this.sv.requestLayout();
                        MainActivity.this.sv.invalidate();
                        
                        break;
                }
            }
    };

    public static MainActivity getInstance()
    {
        return instance;
    }
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		instance = this;
		setContentView(R.layout.activity_main);
        sv = (ScrollView) findViewById(R.id.scr);
		tvf = (MyTextView) findViewById(R.id.tvf);
		tvs = (MyTextView) findViewById(R.id.tvs);
		tve = (MyTextView) findViewById(R.id.tve);
		tvr = (MyTextView) findViewById(R.id.tvr);
		et = (EditText) findViewById(R.id.edt);
		btn = (Button) findViewById(R.id.but);
		btn2 = (Button) findViewById(R.id.ton);
        btn3 = (Button) findViewById(R.id.pro);
        pb = (ProgressBar) findViewById(R.id.prgb);
		btn.setOnClickListener(this);
		btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
		CharSequence cs = getText(R.string.styled);
        tve.setText(cs);
		
		tvf.setText("Welcome to CausFix... (but you can't hear music intro now in this app O.o)");
		String ss = "Choose your *.caustic file who want to be fixing\n" +
		"Then wait for the result output file\n";
		tvs.setText(ss);
		tvr.setText("Result: ");
        
	}
	
	
@Override
public void onClick(View v)
{
		if (v == btn)
		{
	    Intent intent = new Intent(MainActivity.this, FileBrowser.class);
        startActivity(intent);
		}
		if (v == btn2)
		{
		exec();
		}
        if (v == btn3)
		{
		resetFile();
		}
}

public void resLog(String str)
{
tvr.setText("Result: " + str);
Log.i("Causifx", str);
}

public void about()
	{
	try
	 {
            InputStream is = getAssets().open("about.txt");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            String text = new String(buffer);
            linkAlert(text, true);
        } 
        catch (IOException e)
         {
            throw new RuntimeException(e);
        }
	}
	
public void linkAlert(String message, boolean linksClickable) 
            {
        SpannableString spannableString = new SpannableString(message);
        if (linksClickable) 
        {
            Linkify.addLinks(spannableString, Linkify.ALL);
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("About").setMessage(spannableString)
                .setIcon(R.drawable.ic_launcher)
                .setPositiveButton("O.K", null).create();
        dialog.show();
        // Make text links clickable
        if (linksClickable)
         {
            ((TextView) dialog.findViewById(android.R.id.message))
                    .setMovementMethod(LinkMovementMethod.getInstance());
        }
    }
    
@Override
public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.mnu, menu);
		return true;
	}

public boolean onPrepareOptionsMenu(Menu menu)
	{
		super.onPrepareOptionsMenu(menu);
		return true;
	}

@Override
public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.abt:
				about();
				return true;
		}
		return true;
	}
	
@Override
protected void onRestart()
{
super.onRestart();
}

@Override
protected void onDestroy()
{
super.onDestroy();
if (raf != null)
fclose();
}

public void exec()
{
AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Information")
                .setMessage("Fix this file ?")
                .setCancelable(false)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    spath = "";
                    }
                })
        .setPositiveButton("O.K", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                proc();
            }
        })
                .create();
                ad.show();
}

public void resetFile()
{
AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Information")
                .setMessage("Are you sure to reset this file ?")
                .setCancelable(false)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    spath = "";
                    }
                })
        .setPositiveButton("O.K", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                proc2();
            }
        })
                .create();
                ad.show();
}

public void proc()
{
if (spath != null || spath.length() > 0)
{
new Thread(new Runnable()
{
            public void run()
            {
mHandler.sendEmptyMessage(SHOWPROGRESS);
try
{
raf = new RandomAccessFile(spath, "rw");
long fileSize = raf.length();
int fsz = (int)fileSize;
byte[] fileB = new byte[(int)raf.length()];
raf.readFully(fileB, 0, fsz);
String pat = "803F0200000002"; // pattern
String chro = "4368726F6D61746963"; // end marker Chromatic
byte[] bapat = hex2ba(pat);
int posPat = lastIndexOf(fileB, bapat);

byte[] baend = hex2ba(chro);
int posEnd = search(baend, fileB, 0, fsz);
if (posEnd == -1)
{
posEnd = fsz;
}
posEnd = posEnd - 1;
int total = posEnd - posPat;
//resLog("position :" + posPat + " " + posEnd);
if (posPat != -1)
{
byteFill(posPat, total);
resLog("File was fixed!");
} else {
resLog("Fail, you can try reset file");
}}
catch(IOException ioe)
		{
		resLog("FAIL :-(");
		}
mHandler.sendEmptyMessage(DISMISSPROGRESS);
}}).start();
} else {
Toast.makeText(this, "Path file is empty!", Toast.LENGTH_LONG).show();
}}

public void proc2()
{
if (spath != null || spath.length() > 0)
{
new Thread(new Runnable()
{
            public void run()
            {
mHandler.sendEmptyMessage(SHOWPROGRESS);
try
{
raf = new RandomAccessFile(spath, "rw");
long fileSize = raf.length();
int fsz = (int)fileSize;
byte[] fileB = new byte[(int)raf.length()];
raf.readFully(fileB, 0, fsz);
String seqn = "5345514E"; // SEQN
String seq = "534551"; // SEQ
byte[] bapat = hex2ba(seqn);
     
int posPat = search(bapat, fileB, 0, fsz);
if (posPat == -1)
{
byte[] bapat2 = hex2ba(seq);
posPat = search(bapat2, fileB, 0, fsz);
}
posPat = posPat + 4;
int total = fsz - posPat;
byteFill(posPat, total);
resLog("File was fixed!");
}
catch(IOException ioe)
		{
		resLog("FAIL :-(");
		}
mHandler.sendEmptyMessage(DISMISSPROGRESS);
}}).start();
} else {
Toast.makeText(this, "Path file is empty!", Toast.LENGTH_LONG).show();
}}

@Override
protected void onStart()
{
    super.onStart();
    if (!spath.isEmpty())
    et.setText(spath);
}

@Override
public void onBackPressed()
{
    AlertDialog ad = new AlertDialog.Builder(this)
                .setTitle("Confirm")
                .setMessage("Do you want to exit?")
                .setPositiveButton("O.K", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                    MainActivity.super.onBackPressed();
                    finish();
        System.gc();
        System.exit(0);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) 
                    { }
                })
                .create();
                ad.show();
}
    
public int lastIndexOf(byte[] source, byte[] match)
     {
        if (source.length < match.length) 
        {
            return -1;
        }
        for (int i = (source.length - match.length); i >= 0; i--) {
            if (startsWith(source, i, match)) {
                return i;
            }
        }
        return -1;
    }
    
public boolean startsWith(byte[] source, byte[] match) 
    {
        return startsWith(source, 0, match);
    }
    
public boolean startsWith(byte[] source, int offset, byte[] match)
     {
        if (match.length > (source.length - offset))
         {
            return false;
        }
        for (int i = 0; i < match.length; i++) 
        {
            if (source[offset + i] != match[i]) 
            {
                return false;
            }
        }
        return true;
    }
    
public void getfBytes(byte[] source, int srcBegin, int srcEnd, byte[] destination, int dstBegin)
{
        System.arraycopy(source, srcBegin, destination, dstBegin, srcEnd - srcBegin);
    }
    
public byte[] hex2ba(String s)
    {
        int len = s.length();
        byte[] ba = new byte[len / 2];
        for (int i = 0; i < ba.length; i++) {
            int j = i * 2;
            int t = Integer.parseInt(s.substring(j, j + 2), 16);

            byte b = (byte) (t & 0xFF);
            ba[i] = b;
        }
        return ba;
    }
    
public int search(byte[] needle, byte[] haystack, int from, int to)
    {
        int i;
        for (i = from; i < to - needle.length; i++) 
        {
            boolean ok = true;
            
            for (int j = 0; j < needle.length; j++) 
            {
                System.out.println("position :" + j);
                if (needle[j] != haystack[i + j]) {
                    ok = false;
                    
                    break;
                }
            }
            if (ok) {
                return i;
            }
        }
        return -1;
    }
    
public int byteFill(int i2, int i3)
{
        byte[] ba = new byte[256];
        ByteBuffer bb = ByteBuffer.allocate(ba.length);
        int yed = 0;
try
{
        FileChannel fc;
        for(fc = raf.getChannel(); yed < 256; ++yed)
        {
            ba[yed] = 00;
        }
        bb.put(ba);
        bb.flip();
        if(fc != null) {
            long iy = (long)i2;
            fc.position(iy);
            while(true) 
            {
                long kp = iy + (long)ba.length;
                long mk = (long)(i2 + i3);
                if(kp >= mk) {
                    fseek(iy);

                    while(iy < mk) {
                        fputc(00);
                        ++iy;
                    }
                    break;
                }

                iy += (long)fc.write(bb);
                fc.position(iy);
                bb.flip();
            }
        }
        }
        catch (IOException ioe) {}
        return i3;
    }

public void fseek(long var1)
{
        try 
        {
            raf.seek(var1);
        }
        catch (IOException var3)
        {
        }
    }
    
public void fputc(int var1) 
{
        try 
        {
            raf.write(var1);
        } 
        catch (IOException var2)
         {
        }
    }
    
public void fclose()
{
    try
    {
        raf.close();
    }
    catch (IOException io)
    {}
}}

