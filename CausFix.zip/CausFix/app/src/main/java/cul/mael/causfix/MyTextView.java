package cul.mael.causfix;

import cul.mael.causfix.*;

import android.content.*;
import android.graphics.*;
import android.util.*;
import android.widget.*;
import android.annotation.*;
import android.os.*;

public class MyTextView extends TextView
{

    public MyTextView(Context context)
    {
        super(context, null);
    }
    
    public MyTextView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
        init(context);
    }
    
    @TargetApi(16)
    private void init(Context context)
    {
        super.setTypeface(Typeface.createFromAsset(context.getAssets(), "fonts/SourceCodePro-Black.ttf"));
        
        //Set line space to 1.4 times.
        super.setLineSpacing(0f, 1.4f);
        
        //Set edge distance of page.
        int padding_page = getResources().getDimensionPixelSize(R.dimen.padding_text);
        if (Build.VERSION.SDK_INT >= 16)
        {
            super.setPaddingRelative(padding_page, padding_page, padding_page, padding_page);
        }
        else
        {
            super.setPadding(padding_page, padding_page, padding_page, padding_page);
        }
    }
}
